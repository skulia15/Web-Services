/// <summary>
/// Transfers student information
/// </summary>
namespace CoursesAPI.Models.DTOModels {
    public class StudentsDTO {
        // Example 2809952079
        public string ssn { get; set; }
        // Example Skúli Arnarsson
        public string name { get; set; }
    }
}